#include <stdbool.h>
#include <stdlib.h>

// EJERCICIO 2


const char* abb_segundo_maximo(const abb_t* abb) { 
    if (abb_cantidad(abb) < 2) return NULL;

    abb_nodo_t* padre = NULL;
    abb_nodo_t* hijo = abb->raiz;

    while (hijo->der) { // Recorro los mas a la derecha posible.
        padre = hijo;
        hijo = hijo->der;
    }
    if (!hijo->izq) return padre; // Si no hay hijos izq el padre sera el segundo mayor.
    if (hijo->izq && !hijo->izq->der) return hijo->izq; // Si hay pero este no tiene un derecho, el segundo mas grande sera 
    if (hijo->izq && hijo->izq->der) {                  // El hijo->izq.
        hijo = hijo->izq->der;
        while (hijo->der) {  // Esto en el caso que el de la derecha de todo tenga un hijo
            hijo = hijo->der;
        }
        return hijo;
    } 
} // Tambien funciona en el caso que no hay hijo derecho de la raiz pero si izquierdo.

// COMPLEJIDAD:
// La complejidad sera O(log(n)) porque en el peor caso se recorre la altura del arbol, la cual es log(n). 
// (Con n la cantidad de nodos). 
// Todo lo que no son los while es O(1). 

// EJERCICIO 1


bool hallar_match(hash_t* hash) { 
    hash_t* hash_aux = hash_crear(NULL);
    if (!hash_aux) return false;
    hash_iter_t* iter = hash_iter_crear(hash);
    if (!iter) {
        hash_destruir(hash_aux);
        return false;
    }
    
    while (!hash_iter_al_final(iter)) { // O(n)
        if (!hash_pertenece(hash_aux, hash_obtener(hash, hash_iter_ver_actual(iter)))) {
            bool se_guardo = hash_guardar(hash_aux, hash_obtener(hash, hash_iter_ver_actual(iter)), hash_iter_ver_actual(iter));
            if (!se_guardo) {
                hash_iter_destruir(iter);
                hash_destruir(hash_aux);
                return false;
            }
        } 
        else {
            hash_borrar(hash_aux, hash_obtener(hash, hash_iter_ver_actual(iter)));
        }
        hash_iter_avanzar(iter);
    }
    int cantidad = hash_cantidad(hash_aux);

    hash_destruir(hash_aux);
    hash_iter_destruir(iter);

    return cantidad == 0;
}

// COMPLEJIDAD:
//
// La complejidad seria O(n), con n la cantidad de elementos del hash. Como todas las primitivas del hash son O(1),
// la unica complejidad la da el while que recorre todos los elementos (Todo es O(1) menos lo aclarado).
//