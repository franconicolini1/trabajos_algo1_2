#EJERCICIO 8:
# 
# a) Falso. Si bien es cierto que al recorrer una arista que esta en el grafo residual y no en el original
# se va a aumentar el flujo en la arista, la que se modifica es la arista del residual y no la del original.
# es posible que se aumente como tambien es posible que disminuya o quede igual (la del original).
# Pero eso se va a ver recien cuando termine de maximizar el flujo el algoritmo de Ford-Fulkerson.
#
# b) Falso. El problema esta cuando hay ciclos de longitud 2, en ese caso no se puede aplicar directamente 
# el algoritmo de Ford-Fulkerson. Como paso previo se deben eliminar los ciclos de longitud 2 convirtiendolos
# en ciclos de longitud 3. ¿Como? Agregando un vertice que se conecte con los dos vertices para formar un ciclo
# de longitud 3, el cual no genera problemas.
#
# c) Verdadera. Justificacion en pdf. (Accidentalmente lo llame ejercicio 3 en la hoja)
#
#
# EJERCICIO 1:
#
# Aclaracion: Al final es que dijkstra no funciona con pesos negativos.
#
# EJERCICIO 5:


def _len_camino_mas_largo(grafo, v, w, dist_max, visitados, dist_act):
    for ady in grafo.adyacentes(v):
        if ady in visitados: # No vale repetir ya que es simple.
            continue

        if ady == w and dist_act > dist_max:
            dist_max = dist_act
            return

        visitados.add(v)
        dist_act += grafo.peso_arista(v, ady)
        _len_camino_mas_largo(grafo, ady, w, dist_max, visitados, dist_act)

        dist_act -= grafo.peso_arista(v, ady) # Vuelvo a dejar la distancia que habia antes de la llamada recursiva.
        visitados.pop(ady) # En caso que vuelva atras la recursion, para probar todos los caminos posibles.

    return dist_max

def len_camino_mas_largo(grafo, v, w):
    distancias = []
    visitados = set()
    dist_max = 0 # Hago esto porque creo que no funciona pasarle directamente 0.
    dist_act = 0
    return _len_camino_mas_largo(grafo, v, w, dist_max, visitados, dist_act)
